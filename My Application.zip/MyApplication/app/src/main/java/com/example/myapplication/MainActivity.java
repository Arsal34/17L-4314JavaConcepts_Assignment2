package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    //TextView tit2  = (TextView) findViewById(R.id.t2);

    //Button butt2 = (Button) findViewById(R.id.b2);
    //Button butt3 = (Button) findViewById(R.id.b3);
    //Button butt4 = (Button) findViewById(R.id.b4);
    //Button butt5 = (Button) findViewById(R.id.b5);
    //Button butt6 = (Button) findViewById(R.id.b6);

    //Button Bt = (Button) findViewById(R.id.bt2);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_screen);
        //final   TextView tit = (TextView) findViewById(R.id.t1);
      //  Button butt1 = (Button) findViewById(R.id.bt3);
       // butt1.setOnClickListener(new View.OnClickListener() {
        //    public void onClick(View view2) {
         //       Intent intent = new Intent(MainActivity.this,
           //             Main2Activity.class);
             //   startActivity(intent); // startActivity allow you to move
            //}
        //});



    }


}